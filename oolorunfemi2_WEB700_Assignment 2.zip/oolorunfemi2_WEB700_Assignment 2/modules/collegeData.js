const fs = require('fs');

class Data {
  constructor(students, courses) {
    this.students = students;
    this.courses = courses;
  }
}

let entireData = initialize()
let dataCollection = new Data(entireData[0], entireData[1]);

function initialize() {
  const students = new Promise(function (resolve, reject) {
    fs.readFile("./data/students.json", "utf8", (err, data) => {
      if (err) {
        reject("Unable to read file " + err);
      } else {
        try {
          resolve(JSON.parse(data));
        } catch (error) {
          reject("Unexpected error while parsing " + error);
        }
      }
    });
  });
  const courses = new Promise(function (resolve, reject) {
    fs.readFile("./data/courses.json", "utf8", (err, res) => {
      if (err) {
        reject("Unable to read " + err);
      } else {
        try {
          resolve(JSON.parse(res));
        } catch (error) {
          reject("Unexpected error while parsing " + error);
        }
      }
    });
  })
  return [students, courses]
}

function getAllStudents() {
  return dataCollection.students.then(data => {
    if (data.length === 0) {
      return dataCollection.students.reject("No results returned");
    }
    return data
  }, function (error) {
    console.log("An unexpected error occured" + error)
  })
}

function getTAs() {
  return dataCollection.students.then(data => {
    if (data.length === 0) {
      return dataCollection.students.reject("No results returned")
    }
    let realTA = [];
    data.forEach((item, index) => {
      if (item["TA"] === true) {
        realTA.push(item)
      }
    })
    return realTA;
  })
}

function getCourses() {
  return dataCollection.courses.then(
    (data) => {
      if (data.length === 0) {
        return dataCollection.students.reject("No results returned");
      }
      return data
    },
    function (error) {
      console.log("An unexpected error occured" + error);
    }
  );
}


module.exports = {
  Data,
  initialize,
  getAllStudents,
  getTAs,
  getCourses
}